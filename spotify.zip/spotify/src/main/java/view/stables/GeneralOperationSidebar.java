package view.stables;

import javafx.scene.input.MouseEvent;

import java.io.IOException;

public interface GeneralOperationSidebar {
    void search(MouseEvent event) throws IOException;
}
