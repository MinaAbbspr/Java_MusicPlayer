package model.audio;

public enum Genre {
    Rock, Pop, Jazz, HipHop, Country, TrueCrime, Society, InterView, History
}
